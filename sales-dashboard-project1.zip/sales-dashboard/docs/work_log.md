# Work Log

Add one entry per working day. Keep entries short: what you did, what you learned, what is next.

| Date | What was done | Evidence / file | Next |
|---|---|---|---|
| 2026-10-16 | Read the internship handbook. Chose stakeholder (Head of Sales) and decision. Chose Excel. Generated simulated dataset. Wrote requirements and KPI definitions. | `docs/requirements_and_kpis.md`, `data/sales_data_raw.xlsx` | Clean data |
| 2026-10-16 | Ran data validation checks, found 7 problem rows, logged decisions. Built the cleaning script. | `data/cleaning_log.json`, `scripts/clean_data.py` | Build KPIs |
| 2026-10-16 | Calculated KPIs, verified them against an independent pandas calculation, built the Excel dashboard with filters, charts, and validation sheet. Drafted executive summary. | `dashboard/sales_dashboard.xlsx` | Review and practice the demo |
| | _Your entry: re-run both scripts yourself and confirm the results match_ | | |
| | _Your entry: change a filter, spot-check one number by hand_ | | |

Note: the first three entries were completed with Claude's help. From here, add entries in your own words for the work you do yourself (re-running, reviewing, practicing the demo, mentor feedback).
