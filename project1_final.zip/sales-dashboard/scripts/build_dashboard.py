"""Build dashboard/sales_dashboard.xlsx from the cleaned CSVs.
Usage (from project root): python scripts/build_dashboard.py
Then recalculate: python /mnt/skills/public/xlsx/scripts/recalc.py dashboard/sales_dashboard.xlsx
"""
import json
import pandas as pd
from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, Reference
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.worksheet.datavalidation import DataValidation

o = pd.read_csv("data/orders_clean.csv", parse_dates=["order_date"])
t = pd.read_csv("data/traffic.csv")
log = json.load(open("data/cleaning_log.json"))

N = len(o)
LAST = N + 1                      # last data row on Orders sheet
TN = len(t) + 1                   # last data row on Traffic sheet

NAVY, BLUE, LIGHT, YELLOW = "1F4E78", "2E75B6", "DDEBF7", "FFF2CC"
F = "Arial"
f_norm = Font(name=F, size=10)
f_bold = Font(name=F, size=10, bold=True)
f_head = Font(name=F, size=10, bold=True, color="FFFFFF")
f_title = Font(name=F, size=18, bold=True, color=NAVY)
f_sub = Font(name=F, size=10, italic=True, color="595959")
f_input = Font(name=F, size=11, bold=True, color="0000FF")
f_sec = Font(name=F, size=12, bold=True, color=NAVY)
fill_head = PatternFill("solid", fgColor=NAVY)
fill_light = PatternFill("solid", fgColor=LIGHT)
fill_in = PatternFill("solid", fgColor=YELLOW)
thin = Side(style="thin", color="BFBFBF")
box = Border(left=thin, right=thin, top=thin, bottom=thin)
white = Side(style="thick", color="FFFFFF")

wb = Workbook()
ws = wb.active
ws.title = "Dashboard"
ex = wb.create_sheet("Executive Summary")
kd = wb.create_sheet("KPI Definitions")
va = wb.create_sheet("Validation")
od = wb.create_sheet("Orders")
td = wb.create_sheet("Traffic")
li = wb.create_sheet("Lists")


def style_header(sheet, row, c1, c2):
    for c in range(c1, c2 + 1):
        cell = sheet.cell(row=row, column=c)
        cell.font, cell.fill, cell.border = f_head, fill_head, box
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)


def style_body(sheet, r1, r2, c1, c2):
    for r in range(r1, r2 + 1):
        for c in range(c1, c2 + 1):
            cell = sheet.cell(row=r, column=c)
            cell.font, cell.border = f_norm, box


# ---------------------------------------------------------------- Orders
heads = ["order_id", "order_date", "month", "customer_id", "region", "product_id",
         "product_name", "category", "quantity", "unit_price", "discount", "revenue"]
od.append(heads)
for i, r in enumerate(o.itertuples(index=False), start=2):
    od.append([r.order_id, r.order_date.to_pydatetime(), r.month, r.customer_id, r.region,
               r.product_id, r.product_name, r.category, int(r.quantity), float(r.unit_price),
               float(r.discount), f"=I{i}*J{i}*(1-K{i})"])
style_header(od, 1, 1, 12)
for row in od.iter_rows(min_row=2, max_row=LAST):
    for c in row:
        c.font = f_norm
    row[1].number_format = "yyyy-mm-dd"
    row[9].number_format = "#,##0.00"
    row[10].number_format = "0%"
    row[11].number_format = "#,##0.00"
for col, w in zip("ABCDEFGHIJKL", [12, 12, 10, 12, 12, 11, 24, 16, 10, 11, 10, 12]):
    od.column_dimensions[col].width = w
od.freeze_panes = "A2"
od.auto_filter.ref = f"A1:L{LAST}"

# --------------------------------------------------------------- Traffic
td.append(["month", "region", "visits"])
for r in t.itertuples(index=False):
    td.append([r.month, r.region, int(r.visits)])
style_header(td, 1, 1, 3)
style_body(td, 2, TN, 1, 3)
for row in td.iter_rows(min_row=2, max_row=TN, min_col=3, max_col=3):
    row[0].number_format = "#,##0"
for col, w in zip("ABC", [12, 12, 12]):
    td.column_dimensions[col].width = w
td.freeze_panes = "A2"

# ----------------------------------------------------------------- Lists
regions_all = ["All", "East", "North", "West", "South", "Unassigned"]
cats_all = ["All", "Accessories", "Electronics", "Furniture", "Unknown product"]
li["A1"], li["B1"] = "Region options", "Category options"
for i, v in enumerate(regions_all, start=2):
    li.cell(row=i, column=1, value=v)
for i, v in enumerate(cats_all, start=2):
    li.cell(row=i, column=2, value=v)
li["D1"], li["D2"] = "Region criteria", "Category criteria"
li["E1"] = '=IF(Dashboard!$C$4="All","*",Dashboard!$C$4)'
li["E2"] = '=IF(Dashboard!$F$4="All","*",Dashboard!$F$4)'
li["A9"] = "Helper sheet: feeds the dropdowns and turns 'All' into a wildcard (*) for SUMIFS/COUNTIFS. Do not edit."
for row in li.iter_rows(min_row=1, max_row=9):
    for c in row:
        c.font = f_norm
for c in ("A1", "B1", "D1", "D2"):
    li[c].font = f_bold
li.column_dimensions["A"].width = 18
li.column_dimensions["B"].width = 18
li.column_dimensions["D"].width = 18
li.column_dimensions["E"].width = 14

REG = "Lists!$E$1"
CAT = "Lists!$E$2"


def O(col):
    return f"Orders!${col}$2:${col}${LAST}"


def T(col):
    return f"Traffic!${col}$2:${col}${TN}"


# ------------------------------------------------------------- Dashboard
ws.sheet_view.showGridLines = False
for col, w in zip("ABCDEFGHIJ", [2, 24, 14, 14, 14, 14, 14, 14, 14, 3]):
    ws.column_dimensions[col].width = w

ws["B1"] = "Sales Performance Dashboard - 2025"
ws["B1"].font = f_title
ws["B2"] = "Simulated data. Change the yellow filters below and every number and chart updates."
ws["B2"].font = f_sub

ws["B4"], ws["E4"] = "Region filter:", "Category filter:"
ws["B4"].font = ws["E4"].font = f_bold
ws["B4"].alignment = ws["E4"].alignment = Alignment(horizontal="right")
ws["C4"], ws["F4"] = "All", "All"
for c in ("C4", "F4"):
    ws[c].font, ws[c].fill, ws[c].border = f_input, fill_in, box
    ws[c].alignment = Alignment(horizontal="center")
dv1 = DataValidation(type="list", formula1="=Lists!$A$2:$A$7", allow_blank=False)
dv2 = DataValidation(type="list", formula1="=Lists!$B$2:$B$6", allow_blank=False)
ws.add_data_validation(dv1)
ws.add_data_validation(dv2)
dv1.add("C4")
dv2.add("F4")
ws["H4"] = "Note: Conversion needs traffic data, so it shows n/a when a Category is selected."
ws["H4"].font = f_sub

# KPI cards (rows 6-7)
cards = [("B", "C", "Revenue", "=C23", "$#,##0"),
         ("D", "E", "Orders", "=D23", "#,##0"),
         ("F", "G", "Average Order Value", "=IFERROR(C23/D23,0)", "$#,##0.00"),
         ("H", "I", "Conversion Rate", "=G23", "0.00%")]
for c1, c2, label, formula, fmt in cards:
    ws.merge_cells(f"{c1}6:{c2}6")
    ws.merge_cells(f"{c1}7:{c2}7")
    ws[f"{c1}6"] = label
    ws[f"{c1}7"] = formula
    ws[f"{c1}6"].font = Font(name=F, size=10, bold=True, color="FFFFFF")
    ws[f"{c1}7"].font = Font(name=F, size=20, bold=True, color=NAVY)
    ws[f"{c1}7"].number_format = fmt
    for r, fill in ((6, fill_head), (7, fill_light)):
        for col in (c1, c2):
            ws[f"{col}{r}"].fill = fill
            ws[f"{col}{r}"].border = Border(left=white, right=white)
        ws[f"{c1}{r}"].alignment = Alignment(horizontal="center", vertical="center")
ws.row_dimensions[7].height = 36

# Monthly trend (header row 10, data 11-22, total 23)
ws["B9"] = "Monthly trend"
ws["B9"].font = f_sec
for i, h in enumerate(["Month", "Revenue", "Orders", "AOV", "Visits", "Conversion", "Revenue MoM %"]):
    ws.cell(row=10, column=2 + i, value=h)
style_header(ws, 10, 2, 8)
months = [f"2025-{m:02d}" for m in range(1, 13)]
for i, m in enumerate(months):
    r = 11 + i
    ws[f"B{r}"] = m
    ws[f"C{r}"] = f"=SUMIFS({O('L')},{O('C')},$B{r},{O('E')},{REG},{O('H')},{CAT})"
    ws[f"D{r}"] = f"=COUNTIFS({O('C')},$B{r},{O('E')},{REG},{O('H')},{CAT})"
    ws[f"E{r}"] = f"=IFERROR(C{r}/D{r},0)"
    ws[f"F{r}"] = f"=SUMIFS({T('C')},{T('A')},$B{r},{T('B')},{REG})"
    ws[f"G{r}"] = f'=IF($F$4<>"All","n/a",IFERROR(D{r}/F{r},"n/a"))'
    ws[f"H{r}"] = "-" if i == 0 else f"=IFERROR(C{r}/C{r-1}-1,0)"
ws["B23"] = "Total / average"
ws["C23"] = "=SUM(C11:C22)"
ws["D23"] = "=SUM(D11:D22)"
ws["E23"] = "=IFERROR(C23/D23,0)"
ws["F23"] = "=SUM(F11:F22)"
ws["G23"] = '=IF($F$4<>"All","n/a",IFERROR(D23/F23,"n/a"))'
style_body(ws, 11, 23, 2, 8)
for c in range(2, 9):
    ws.cell(row=23, column=c).font = f_bold
    ws.cell(row=23, column=c).fill = fill_light
for r in range(11, 24):
    ws[f"C{r}"].number_format = "$#,##0"
    ws[f"D{r}"].number_format = "#,##0"
    ws[f"E{r}"].number_format = "$#,##0.00"
    ws[f"F{r}"].number_format = "#,##0"
    ws[f"G{r}"].number_format = "0.00%"
    ws[f"H{r}"].number_format = "0.0%;[Red]-0.0%"
    ws[f"G{r}"].alignment = ws[f"H{r}"].alignment = Alignment(horizontal="right")

# Region table (filtered by Category only)
reg_order = ["East", "North", "West", "South", "Unassigned"]
ws["B26"] = "Performance by region (responds to Category filter)"
ws["B26"].font = f_sec
for i, h in enumerate(["Region", "Revenue", "Revenue share", "Orders", "AOV", "Visits", "Conversion"]):
    ws.cell(row=27, column=2 + i, value=h)
style_header(ws, 27, 2, 8)
for i, rg in enumerate(reg_order):
    r = 28 + i
    ws[f"B{r}"] = rg
    ws[f"C{r}"] = f"=SUMIFS({O('L')},{O('E')},$B{r},{O('H')},{CAT})"
    ws[f"D{r}"] = f"=IFERROR(C{r}/$C$33,0)"
    ws[f"E{r}"] = f"=COUNTIFS({O('E')},$B{r},{O('H')},{CAT})"
    ws[f"F{r}"] = f"=IFERROR(C{r}/E{r},0)"
    ws[f"G{r}"] = f"=SUMIFS({T('C')},{T('B')},$B{r})"
    ws[f"H{r}"] = f'=IF($F$4<>"All","n/a",IFERROR(E{r}/G{r},"n/a"))'
ws["B33"] = "Total"
ws["C33"] = "=SUM(C28:C32)"
ws["D33"] = "=SUM(D28:D32)"
ws["E33"] = "=SUM(E28:E32)"
ws["F33"] = "=IFERROR(C33/E33,0)"
ws["G33"] = "=SUM(G28:G32)"
ws["H33"] = '=IF($F$4<>"All","n/a",IFERROR(E33/G33,"n/a"))'
style_body(ws, 28, 33, 2, 8)
for c in range(2, 9):
    ws.cell(row=33, column=c).font = f_bold
    ws.cell(row=33, column=c).fill = fill_light
for r in range(28, 34):
    ws[f"C{r}"].number_format = "$#,##0"
    ws[f"D{r}"].number_format = "0.0%"
    ws[f"E{r}"].number_format = "#,##0"
    ws[f"F{r}"].number_format = "$#,##0.00"
    ws[f"G{r}"].number_format = "#,##0"
    ws[f"H{r}"].number_format = "0.00%"
    ws[f"H{r}"].alignment = Alignment(horizontal="right")

# Product table (filtered by Region and Category)
prod_order = (o.groupby("product_name").revenue.sum().sort_values(ascending=False).index.tolist())
prod_order = [p for p in prod_order if p != "Unknown product"] + ["Unknown product"]
PR1 = 38
PR2 = PR1 + len(prod_order) - 1
PT = PR2 + 1
ws["B36"] = "Performance by product (responds to both filters; order fixed by full-year revenue)"
ws["B36"].font = f_sec
for i, h in enumerate(["Product", "Revenue", "Revenue share", "Units", "Orders", "Avg discount"]):
    ws.cell(row=37, column=2 + i, value=h)
style_header(ws, 37, 2, 7)
for i, p in enumerate(prod_order):
    r = PR1 + i
    ws[f"B{r}"] = p
    ws[f"C{r}"] = f"=SUMIFS({O('L')},{O('G')},$B{r},{O('E')},{REG},{O('H')},{CAT})"
    ws[f"D{r}"] = f"=IFERROR(C{r}/$C${PT},0)"
    ws[f"E{r}"] = f"=SUMIFS({O('I')},{O('G')},$B{r},{O('E')},{REG},{O('H')},{CAT})"
    ws[f"F{r}"] = f"=COUNTIFS({O('G')},$B{r},{O('E')},{REG},{O('H')},{CAT})"
    ws[f"G{r}"] = (f"=IFERROR(SUMIFS({O('K')},{O('G')},$B{r},{O('E')},{REG},{O('H')},{CAT})/F{r},0)")
ws[f"B{PT}"] = "Total"
ws[f"C{PT}"] = f"=SUM(C{PR1}:C{PR2})"
ws[f"D{PT}"] = f"=SUM(D{PR1}:D{PR2})"
ws[f"E{PT}"] = f"=SUM(E{PR1}:E{PR2})"
ws[f"F{PT}"] = f"=SUM(F{PR1}:F{PR2})"
ws[f"G{PT}"] = (f"=IFERROR(SUMIFS({O('K')},{O('E')},{REG},{O('H')},{CAT})/F{PT},0)")
style_body(ws, PR1, PT, 2, 7)
for c in range(2, 8):
    ws.cell(row=PT, column=c).font = f_bold
    ws.cell(row=PT, column=c).fill = fill_light
for r in range(PR1, PT + 1):
    ws[f"C{r}"].number_format = "$#,##0"
    ws[f"D{r}"].number_format = "0.0%"
    ws[f"E{r}"].number_format = "#,##0"
    ws[f"F{r}"].number_format = "#,##0"
    ws[f"G{r}"].number_format = "0.0%"

# Category table (filtered by Region only)
CR0 = PT + 3
ws[f"B{CR0-1}"] = "Performance by category (responds to Region filter)"
ws[f"B{CR0-1}"].font = f_sec
for i, h in enumerate(["Category", "Revenue", "Revenue share", "Orders", "Share of orders", "AOV"]):
    ws.cell(row=CR0, column=2 + i, value=h)
style_header(ws, CR0, 2, 7)
cat_list = ["Electronics", "Furniture", "Accessories", "Unknown product"]
C1 = CR0 + 1
C2 = C1 + len(cat_list) - 1
CT = C2 + 1
for i, cg in enumerate(cat_list):
    r = C1 + i
    ws[f"B{r}"] = cg
    ws[f"C{r}"] = f"=SUMIFS({O('L')},{O('H')},$B{r},{O('E')},{REG})"
    ws[f"D{r}"] = f"=IFERROR(C{r}/$C${CT},0)"
    ws[f"E{r}"] = f"=COUNTIFS({O('H')},$B{r},{O('E')},{REG})"
    ws[f"F{r}"] = f"=IFERROR(E{r}/$E${CT},0)"
    ws[f"G{r}"] = f"=IFERROR(C{r}/E{r},0)"
ws[f"B{CT}"] = "Total"
ws[f"C{CT}"] = f"=SUM(C{C1}:C{C2})"
ws[f"D{CT}"] = f"=SUM(D{C1}:D{C2})"
ws[f"E{CT}"] = f"=SUM(E{C1}:E{C2})"
ws[f"F{CT}"] = f"=SUM(F{C1}:F{C2})"
ws[f"G{CT}"] = f"=IFERROR(C{CT}/E{CT},0)"
style_body(ws, C1, CT, 2, 7)
for c in range(2, 8):
    ws.cell(row=CT, column=c).font = f_bold
    ws.cell(row=CT, column=c).fill = fill_light
for r in range(C1, CT + 1):
    ws[f"C{r}"].number_format = "$#,##0"
    ws[f"D{r}"].number_format = "0.0%"
    ws[f"E{r}"].number_format = "#,##0"
    ws[f"F{r}"].number_format = "0.0%"
    ws[f"G{r}"].number_format = "$#,##0.00"

# Charts (to the right of the tables, column K onward)
def style_chart(ch, title, w=17, h=7.5):
    ch.title = title
    ch.width, ch.height = w, h
    ch.legend = None


line = LineChart()
line.add_data(Reference(ws, min_col=3, min_row=10, max_row=22), titles_from_data=True)
line.set_categories(Reference(ws, min_col=2, min_row=11, max_row=22))
style_chart(line, "Monthly revenue")
line.series[0].graphicalProperties.line.solidFill = NAVY
line.series[0].graphicalProperties.line.width = 28000
line.series[0].smooth = False
line.y_axis.numFmt = "$#,##0"
line.y_axis.delete = False
line.x_axis.delete = False
ws.add_chart(line, "K9")

b1 = BarChart()
b1.type = "col"
b1.add_data(Reference(ws, min_col=3, min_row=27, max_row=31), titles_from_data=True)
b1.set_categories(Reference(ws, min_col=2, min_row=28, max_row=31))
style_chart(b1, "Revenue by region")
b1.series[0].graphicalProperties.solidFill = BLUE
b1.y_axis.numFmt = "$#,##0"
b1.y_axis.delete = False
b1.x_axis.delete = False
ws.add_chart(b1, "K25")

b2 = BarChart()
b2.type = "bar"
b2.add_data(Reference(ws, min_col=3, min_row=37, max_row=PR2 - 1), titles_from_data=True)
b2.set_categories(Reference(ws, min_col=2, min_row=PR1, max_row=PR2 - 1))
style_chart(b2, "Revenue by product", h=9)
b2.series[0].graphicalProperties.solidFill = NAVY
b2.x_axis.scaling.orientation = "maxMin"
b2.y_axis.numFmt = "$#,##0"
b2.y_axis.delete = False
b2.x_axis.delete = False
ws.add_chart(b2, "K41")

b3 = BarChart()
b3.type = "col"
b3.add_data(Reference(ws, min_col=3, min_row=CR0, max_row=C2 - 1), titles_from_data=True)
b3.set_categories(Reference(ws, min_col=2, min_row=C1, max_row=C2 - 1))
style_chart(b3, "Revenue by category", h=6.5)
b3.series[0].graphicalProperties.solidFill = BLUE
b3.y_axis.numFmt = "$#,##0"
b3.y_axis.delete = False
b3.x_axis.delete = False
ws.add_chart(b3, "K60")

# --------------------------------------------------------- Exec summary
ex.sheet_view.showGridLines = False
ex.column_dimensions["A"].width = 2
ex.column_dimensions["B"].width = 6
ex.column_dimensions["C"].width = 110
ex["B1"] = "Executive Summary - Sales Performance 2025"
ex["B1"].font = f_title
ex["B2"] = ("For: Head of Sales | Decision: where to focus sales and marketing effort next quarter | "
            "Figures: full year, all regions, after data cleaning.")
ex["B2"].font = f_sub
rows = [
    ("h", "Headline"),
    ("t", "2025 revenue was $607,403 from 2,626 orders. Average order value was $231.30 and overall conversion was 3.38% "
          "(2,626 orders from 77,678 visits)."),
    ("h", "Three findings"),
    ("n", "1", "Revenue depends heavily on one product. Laptop Pro 15 brings in 37.5% of revenue and Electronics 65.4%, "
               "while Accessories make up 46.8% of orders but only 12.9% of revenue."),
    ("n", "2", "Q4 is the biggest period (31.1% of revenue), but November exposed a conversion problem. Visits jumped 67% "
               "over October (6,089 to 10,191) while orders grew only 38%, so conversion fell to 2.97%, the lowest of the year."),
    ("n", "3", "Regions behave differently. East leads revenue (29.9%). South converts best (3.53%) but has the least traffic "
               "(14,553 visits). North has the highest order value ($240.53) but the lowest conversion (3.23%)."),
    ("h", "Three recommended actions"),
    ("n", "1", "Test more traffic to South: run a one-quarter campaign aimed at +20% visits and check that conversion holds "
               "near 3.5%."),
    ("n", "2", "Prepare for the next November peak: review the site and checkout under heavy traffic and test landing pages. "
               "Target a November conversion of at least 3.3% (the yearly average is 3.38%)."),
    ("n", "3", "Grow order value and tighten discounts: bundle Accessories with Laptops and Monitors. Discounts cost $34,722 "
               "(5.4% of gross sales) and are applied evenly across all products (about 5% each), so replace them with "
               "targeted offers."),
    ("h", "Limitations"),
    ("t", "The data is simulated, so real patterns will differ. Regional conversion differences are small (3.2% to 3.5%) "
          "and could be noise; confirm with an A/B test before moving big budgets. No cost data was available, so profit "
          "and margin are out of scope. Seven raw rows (0.3%) were fixed, labeled or removed during cleaning; see the Validation sheet."),
    ("h", "Next steps"),
    ("t", "Add cost data to measure profit by product, add customer-level data to measure repeat purchase, and replace the "
          "simulated traffic with real web analytics."),
]
r = 4
for item in rows:
    if item[0] == "h":
        r += 1
        ex[f"B{r}"] = item[1]
        ex[f"B{r}"].font = f_sec
        r += 1
    elif item[0] == "t":
        ex.merge_cells(f"B{r}:C{r}")
        ex[f"B{r}"] = item[1]
        ex[f"B{r}"].font = f_norm
        ex[f"B{r}"].alignment = Alignment(wrap_text=True, vertical="top")
        ex.row_dimensions[r].height = 15 * (1 + len(item[1]) // 125)
        r += 1
    else:
        ex[f"B{r}"] = item[1] + "."
        ex[f"B{r}"].font = f_bold
        ex[f"B{r}"].alignment = Alignment(horizontal="right", vertical="top")
        ex[f"C{r}"] = item[2]
        ex[f"C{r}"].font = f_norm
        ex[f"C{r}"].alignment = Alignment(wrap_text=True, vertical="top")
        ex.row_dimensions[r].height = 15 * (1 + len(item[2]) // 115)
        r += 1

# --------------------------------------------------------- KPI definitions
kd.sheet_view.showGridLines = False
kd["A1"] = "KPI Definitions"
kd["A1"].font = f_title
for i, h in enumerate(["KPI", "Formula", "How it is calculated on the Dashboard"]):
    kd.cell(row=3, column=1 + i, value=h)
style_header(kd, 3, 1, 3)
defs = [
    ("Revenue", "SUM(quantity x unit_price x (1 - discount))", "SUMIFS over Orders!revenue (revenue is itself a formula per row)"),
    ("Orders", "Count of unique order_id", "COUNTIFS on cleaned Orders (duplicates already removed)"),
    ("Average Order Value (AOV)", "Revenue / Orders", "Total revenue divided by total orders, never an average of averages"),
    ("Conversion Rate", "Orders / Visits", "Orders divided by Traffic visits for the same month and region; totals are divided, monthly rates are never averaged"),
    ("Revenue share", "Item revenue / total revenue", "Shown for region, product and category"),
    ("Revenue MoM %", "(This month / last month) - 1", "Month-over-month change in revenue"),
    ("Average discount", "Average of the discount column", "Per product, across its orders"),
]
for i, d in enumerate(defs, start=4):
    for j, v in enumerate(d):
        kd.cell(row=i, column=1 + j, value=v)
style_body(kd, 4, 3 + len(defs), 1, 3)
for rr in range(4, 4 + len(defs)):
    for cc in range(1, 4):
        kd.cell(row=rr, column=cc).alignment = Alignment(wrap_text=True, vertical="top")
kd.column_dimensions["A"].width = 28
kd.column_dimensions["B"].width = 44
kd.column_dimensions["C"].width = 80

# -------------------------------------------------------------- Validation
va.sheet_view.showGridLines = False
va["A1"] = "Data Validation Evidence"
va["A1"].font = f_title
va["A3"] = "A. Data issues found in the raw file and decisions taken"
va["A3"].font = f_sec
for i, h in enumerate(["Check", "Rows affected", "Decision", "Example order IDs"]):
    va.cell(row=4, column=1 + i, value=h)
style_header(va, 4, 1, 4)
for i, iss in enumerate(log["issues"], start=5):
    va.cell(row=i, column=1, value=iss["check"])
    va.cell(row=i, column=2, value=iss["count"])
    va.cell(row=i, column=3, value=iss["decision"])
    va.cell(row=i, column=4, value=", ".join(iss["examples"]))
last_issue = 4 + len(log["issues"])
style_body(va, 5, last_issue, 1, 4)
for rr in range(5, last_issue + 1):
    for cc in (1, 3, 4):
        va.cell(row=rr, column=cc).alignment = Alignment(wrap_text=True, vertical="top")

b = last_issue + 3
va[f"A{b-1}"] = "B. Live reconciliation checks (formulas)"
va[f"A{b-1}"].font = f_sec
for i, h in enumerate(["Check", "Expected", "Actual", "Result"]):
    va.cell(row=b, column=1 + i, value=h)
style_header(va, b, 1, 4)
removed = sum(i["count"] for i in log["issues"] if i["check"] in ("Duplicate order_id", "Quantity <= 0", "Order date outside 2025"))
checks = [
    ("Clean rows = raw rows - removed rows", f"={log['rows_raw']}-{removed}", f"=COUNTA({O('A')})"),
    ("Duplicate order IDs remaining", 0, f"=SUMPRODUCT((COUNTIF({O('A')},{O('A')})>1)*1)"),
    ("Rows with quantity <= 0", 0, f'=COUNTIF({O("I")},"<=0")'),
    ("Rows with blank region", 0, f"=COUNTBLANK({O('E')})"),
    ("Total revenue vs independent pandas calculation", log["revenue_clean"], f"=ROUND(SUM({O('L')}),2)"),
    ("Monthly total = region total (both filters All)", f"=SUM({O('L')})", "=Dashboard!C23-Dashboard!C33"),
]
for i, (name, exp, act) in enumerate(checks, start=b + 1):
    va.cell(row=i, column=1, value=name)
    va.cell(row=i, column=2, value=exp)
    va.cell(row=i, column=3, value=act)
# last check is a difference; rewrite so expected is 0
last = b + len(checks)
va.cell(row=last, column=2, value=0)
va.cell(row=last, column=1, value="Monthly total minus region total (both filters set to All)")
for i in range(b + 1, last):
    va.cell(row=i, column=4, value=f'=IF(ABS(B{i}-C{i})<0.01,"PASS","FAIL")')
va.cell(row=last, column=4, value=f'=IF(OR(Dashboard!$C$4<>"All",Dashboard!$F$4<>"All"),"Set both filters to All",IF(ABS(B{last}-C{last})<0.01,"PASS","FAIL"))')
style_body(va, b + 1, last, 1, 4)
for i in range(b + 1, last + 1):
    va.cell(row=i, column=2).number_format = "#,##0.00"
    va.cell(row=i, column=3).number_format = "#,##0.00"
    va.cell(row=i, column=4).font = f_bold
    va.cell(row=i, column=4).alignment = Alignment(horizontal="center")
va.cell(row=b + 5, column=2).number_format = "$#,##0.00"
va.cell(row=b + 5, column=3).number_format = "$#,##0.00"
va[f"A{last+2}"] = ("Cleaning is reproducible: run scripts/clean_data.py on data/sales_data_raw.xlsx. "
                    "The raw file is never edited.")
va[f"A{last+2}"].font = f_sub
va.column_dimensions["A"].width = 52
va.column_dimensions["B"].width = 16
va.column_dimensions["C"].width = 60
va.column_dimensions["D"].width = 30

for hr in (10, 27, 37, CR0):
    ws.row_dimensions[hr].height = 30
ws.freeze_panes = "A5"
wb.save("dashboard/sales_dashboard.xlsx")
print("saved; orders rows", N, "product rows", PR1, PR2, "cat rows", C1, C2)
