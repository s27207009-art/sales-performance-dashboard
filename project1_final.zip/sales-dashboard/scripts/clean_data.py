"""Clean the raw sales workbook. Usage: python scripts/clean_data.py
Reads data/sales_data_raw.xlsx, writes data/orders_clean.csv, data/traffic.csv,
data/products.csv and data/cleaning_log.json (every issue found and the decision taken)."""
import json
import pandas as pd

raw = "data/sales_data_raw.xlsx"
orders = pd.read_excel(raw, sheet_name="Orders")
products = pd.read_excel(raw, sheet_name="Products")
traffic = pd.read_excel(raw, sheet_name="Traffic")
log = {"rows_raw": len(orders), "issues": []}

def note(check, count, decision, ids=None):
    log["issues"].append({"check": check, "count": int(count), "decision": decision,
                          "examples": [str(i) for i in (ids or [])][:5]})

# 1. exact duplicate order IDs -> keep first
dup = orders[orders.duplicated("order_id", keep="first")]
note("Duplicate order_id", len(dup), "Removed (kept first occurrence)", dup.order_id.tolist())
orders = orders.drop_duplicates("order_id", keep="first")

# 2. missing region -> keep revenue, label 'Unassigned'
miss = orders[orders.region.isna()]
note("Missing region", len(miss), "Kept; region set to 'Unassigned' (revenue is real, region cannot be inferred)", miss.order_id.tolist())
orders["region"] = orders.region.fillna("Unassigned")

# 3. non-positive quantity -> exclude
bad_q = orders[orders.quantity <= 0]
note("Quantity <= 0", len(bad_q), "Excluded (likely return or entry error, no way to verify)", bad_q.order_id.tolist())
orders = orders[orders.quantity > 0]

# 4. unknown product id -> keep, label Unknown
unk = orders[~orders.product_id.isin(products.product_id)]
note("product_id not in Products", len(unk), "Kept; product/category set to 'Unknown product'", unk.order_id.tolist())

# 5. revenue must equal qty * unit_price * (1 - discount) -> recompute
expected = (orders.quantity * orders.unit_price * (1 - orders.discount)).round(2)
mism = orders[(orders.revenue - expected).abs() > 0.01]
note("Revenue != qty x price x (1-discount)", len(mism), "Corrected: revenue recalculated from components", mism.order_id.tolist())
orders["revenue"] = expected

# 6. dates inside 2025
out = orders[(orders.order_date < "2025-01-01") | (orders.order_date > "2025-12-31")]
note("Order date outside 2025", len(out), "Excluded" if len(out) else "None found", out.order_id.tolist())
orders = orders[~orders.order_id.isin(out.order_id)]

orders = orders.merge(products[["product_id", "product_name", "category"]], on="product_id", how="left")
orders["product_name"] = orders.product_name.fillna("Unknown product")
orders["category"] = orders.category.fillna("Unknown product")
orders["month"] = pd.to_datetime(orders.order_date).dt.to_period("M").astype(str)
orders = orders.sort_values("order_date").reset_index(drop=True)

log["rows_clean"] = len(orders)
log["revenue_clean"] = round(float(orders.revenue.sum()), 2)
orders.to_csv("data/orders_clean.csv", index=False)
traffic.assign(month=pd.to_datetime(traffic.month).dt.to_period("M").astype(str)).to_csv("data/traffic.csv", index=False)
products.to_csv("data/products.csv", index=False)
json.dump(log, open("data/cleaning_log.json", "w"), indent=2)
print(json.dumps(log, indent=2))
