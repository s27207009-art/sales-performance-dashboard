# Sales Performance Dashboard (Project 1)

Arrowstack Data Analytics Internship, Project 1. A KPI dashboard in Excel for a Head of Sales, built on simulated 2025 sales data for four regions and ten products.

**Business question:** Which regions and products should we focus on next quarter, and why?

## What is in this folder

| Path | What it is |
|---|---|
| `dashboard/sales_dashboard.xlsx` | The deliverable. Sheets: Dashboard, Executive Summary, KPI Definitions, Validation, Orders, Traffic, Lists |
| `data/sales_data_raw.xlsx` | Raw simulated data (never edited) |
| `data/orders_clean.csv`, `traffic.csv`, `products.csv` | Cleaned data produced by the script |
| `data/cleaning_log.json` | Every data issue found and the decision taken |
| `scripts/clean_data.py` | Cleaning script (pandas) |
| `scripts/build_dashboard.py` | Builds the Excel dashboard from the cleaned data |
| `docs/requirements_and_kpis.md` | Stakeholder, scope, KPI formulas, acceptance criteria |
| `docs/decision_log.md` | Key decisions and why |
| `docs/work_log.md` | Dated work log |
| `docs/presentation_and_viva.md` | 5-minute demo script and interview answers |

## How to use the dashboard

1. Open `dashboard/sales_dashboard.xlsx` and go to the **Dashboard** sheet.
2. Use the yellow **Region** and **Category** dropdowns (cells C4 and F4). All cards, tables and charts update.
3. Read the **Executive Summary** sheet for findings and actions.
4. Check the **Validation** sheet: every reconciliation check should say PASS (set both filters to All for the last one).

## How to reproduce

Requires Python 3 with `pandas` and `openpyxl`.

```
python scripts/clean_data.py        # raw -> cleaned CSVs + cleaning_log.json
python scripts/build_dashboard.py   # cleaned CSVs -> dashboard/sales_dashboard.xlsx
```

The built workbook stores formulas without values until it is opened in Excel (or recalculated in LibreOffice), so open it and let Excel calculate before reading it with other tools.

## Headline results (2025, all regions)

- Revenue $607,403, 2,626 orders, AOV $231.30, conversion 3.38%
- Laptop Pro 15 is 37.5% of revenue; Electronics is 65.4%
- November visits rose 67% but orders only 38%, so conversion dropped to 2.97%
- South converts best (3.53%) with the least traffic; North has the lowest conversion (3.23%)

## Data cleaning summary

Raw 2,629 rows became 2,626. Two duplicates and one negative-quantity row were removed; two missing regions were labeled Unassigned; one unknown product was labeled Unknown product; one wrong revenue value was recalculated. Details are in the Validation sheet.

## Limitations

- Data is simulated; real patterns will differ.
- Regional conversion gaps are small and may be noise.
- Conversion is orders divided by visits per month and region, not a per-customer funnel.
- No cost data, so no profit or margin analysis.
- Dropdown filters were used instead of PivotTable slicers so that the workbook rebuilds from a script. In Excel you can add slicers on top if you convert the data to PivotTables.

## Next improvements

Add cost data for margin analysis, customer IDs for repeat-purchase analysis, and real web analytics for traffic. See the extension ideas in the internship handbook.
