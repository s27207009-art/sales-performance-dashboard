# Project 1: Sales Performance Dashboard — Requirements & KPI Definitions

**Tool:** Excel (PivotTables, slicers, charts) | **Data:** simulated (`sales_data.xlsx`, calendar year 2025)

---

## 1. Stakeholder and decision

- **Primary stakeholder:** Head of Sales at a company selling laptops, accessories and furniture across 4 regions (North, South, East, West).
- **Decision the dashboard supports:** Where to focus sales and marketing effort next quarter: which regions and products to push, and where conversion or order value is lagging.
- **Measurable benefit:** Spot the weakest region/product within minutes instead of manually combining reports.

## 2. Scope

**In scope:** Revenue, conversion rate, average order value (AOV), region performance, product/category performance, monthly trend, interactive filters, executive summary.

**Out of scope:** Profit/margin (no cost data), customer lifetime value, forecasting.

## 3. Data description

| Sheet | Columns | Rows |
|---|---|---|
| Orders | order_id, order_date, customer_id, region, product_id, quantity, unit_price, discount, revenue | ~2,600 |
| Products | product_id, product_name, category, list_price | 10 |
| Traffic | month, region, visits | 48 (12 months x 4 regions) |

Orders link to Products on `product_id`. Traffic links to Orders by month and region.

## 4. KPI definitions

| KPI | Formula | Notes |
|---|---|---|
| Revenue | SUM(quantity x unit_price x (1 - discount)) | Use the `revenue` column after cleaning |
| Orders | COUNT of unique order_id | Remove duplicates first |
| Average Order Value (AOV) | Revenue / Orders | |
| Conversion Rate | Orders / Visits | Calculated per month and region; never average the monthly rates, divide totals |
| Revenue by Region | Revenue grouped by region | |
| Revenue by Product / Category | Revenue grouped by product_name / category | Needs lookup to Products sheet |
| Monthly Trend | Revenue and Orders by month | Also compare month-over-month % change |

## 5. Data validation checklist (do this before any analysis)

The dataset contains **deliberate problems**, as real data does. Find them, fix or exclude them, and log what you did.

- [ ] Duplicate order IDs (Data > Remove Duplicates, or COUNTIF > 1)
- [ ] Missing region values (filter blanks)
- [ ] Negative or zero quantities
- [ ] Revenue that does not match quantity x unit_price x (1 - discount)
- [ ] product_id values that do not exist in the Products sheet (VLOOKUP/XLOOKUP returns #N/A)
- [ ] Dates outside 2025
- [ ] Record before/after row counts in `validation_log.md`

## 6. Dashboard requirements

1. KPI cards: Revenue, Orders, AOV, Conversion Rate
2. Monthly revenue trend (line chart)
3. Revenue by region (bar chart)
4. Top products / categories (bar chart)
5. Slicers: Month, Region, Category
6. Executive summary: 3 findings and 3 recommended actions in plain language

## 7. Acceptance criteria

- All KPIs match a manual spot-check on at least 2 filtered views.
- Every data issue found is documented, with the decision made (fixed, excluded, kept).
- Slicers update all charts and cards together.
- A mentor can open the workbook and understand each sheet without asking you.
- You can explain every number on the dashboard.

## 8. Success metric

The dashboard answers: *"Which region and product should we focus on next quarter, and why?"* in under 2 minutes.

## 9. Folder structure

```
sales-dashboard/
  data/        raw data (never edit the original)
  docs/        requirements, validation log, decision log, work log
  sql/         optional SQL queries (extension)
  dashboard/   your Excel dashboard
  README.md
```

## 10. Four-week plan

| Week | Goal | Output |
|---|---|---|
| 1 | Frame problem, requirements, load data, first look | This doc, folder setup, work log started |
| 2 | Clean data, build KPIs and PivotTables | Cleaned data, validation log, KPI sheet |
| 3 | Build dashboard with charts and slicers, test it | Working dashboard, test evidence |
| 4 | Executive summary, README, presentation | Final package, 5-minute demo |

## 11. Week 1 to-do

- [ ] Create the folder structure above and copy `sales_data.xlsx` into `data/` (keep a read-only original)
- [ ] Start `docs/work_log.md` with today's date
- [ ] Read this document and write 3 sentences in your own words: who is the user, what decision, what does success look like
- [ ] Open the workbook, look at each sheet, and note 5 observations (row counts, date range, anything odd)
- [ ] Try one PivotTable: total revenue by region
- [ ] Create a Git repo (or dated evidence folder) and make your first commit

## 12. Assumptions and limitations

- Data is simulated; real patterns and seasonality will differ.
- Conversion is orders / visits at month-region level, not per customer journey.
- No cost data, so no profit analysis.
