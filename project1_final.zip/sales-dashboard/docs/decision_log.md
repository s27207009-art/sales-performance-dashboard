# Decision Log

| # | Decision | Why | Alternative considered |
|---|---|---|---|
| 1 | Build in Excel | Free to learn, most familiar for a beginner, no account needed | Power BI (Windows only), Looker Studio (needs Google Sheets) |
| 2 | Use simulated data with planted errors | Safe and authorized; lets the validation step be practiced | Public Kaggle dataset |
| 3 | Keep raw data untouched, clean with a script | Reproducible; a mentor can re-run it | Manual edits in Excel |
| 4 | Remove duplicate order IDs (keep first) | An order should be counted once | Keep and flag |
| 5 | Exclude the row with negative quantity | Cannot tell if it is a return or an entry error; only 1 row | Convert to positive |
| 6 | Label missing regions "Unassigned" and keep them | The revenue is real ($111), region cannot be guessed, and dropping would understate total revenue | Delete rows |
| 7 | Label unknown product ID "Unknown product" and keep | Revenue is real ($153); flagged so it is visible | Delete row |
| 8 | Recalculate revenue from quantity x price x (1 - discount) | One value was wildly wrong (99,999.99); the components are consistent | Exclude row |
| 9 | Conversion = total orders / total visits | Averaging monthly rates would weight small months too much | Average of monthly rates |
| 10 | Dropdown filters (data validation + SUMIFS) instead of slicers | Works from a script, easy to read, beginner friendly | PivotTable slicers |
| 11 | Show conversion as n/a when a Category is selected | Traffic data has no category, so the number would be wrong | Allocate visits by share (guesswork) |
| 12 | Keep the narrative in Executive Summary as text for the full-year view | A written summary should not change when filters move | Formula-driven text |
