# Work Log

Add one entry per working day. Keep entries short: what you did, what you learned, what is next.

| Date | What was done | Evidence / file | Next |
|---|---|---|---|
| 2026-10-16 | Read the internship handbook. Chose stakeholder (Head of Sales) and decision. Chose Excel. Generated simulated dataset. Wrote requirements and KPI definitions. | `docs/requirements_and_kpis.md`, `data/sales_data_raw.xlsx` | Clean data |
| 2026-10-16 | Ran data validation checks, found 7 problem rows, logged decisions. Built the cleaning script. | `data/cleaning_log.json`, `scripts/clean_data.py` | Build KPIs |
| 2026-10-16 | Calculated KPIs, verified them against an independent pandas calculation, built the Excel dashboard with filters, charts, and validation sheet. Drafted executive summary. | `dashboard/sales_dashboard.xlsx` | Review and practice the demo |
| 2026-10-17 | Re-ran `clean_data.py` and `build_dashboard.py` from the raw file. The cleaning log was identical to the earlier run (2,629 raw rows, 2,626 clean, revenue $607,402.75). Recalculated the workbook; all 6 Validation checks show PASS. | `data/cleaning_log.json`, `dashboard/sales_dashboard.xlsx` | Spot-check filtered views |
| 2026-10-17 | Spot-checked two filtered views against an independent pandas calculation. Region=South: $120,649, 513 orders, AOV $235.18, conversion 3.53%. Region=East + Category=Electronics: $114,649.50, 235 orders, AOV $487.87, conversion n/a (as designed). Both matched the dashboard. Also re-checked the executive summary figures (Laptop 37.5%, Nov conversion 2.97%, discounts $34,722) against the data. | Dashboard filters C4/F4 | Practice the 5-minute demo; post on LinkedIn |

**Read this entry as a draft.** Re-run the two spot-checks yourself in Excel so you can explain them in your own words.

Note: the first three entries were completed with Claude's help. From here, add entries in your own words for the work you do yourself (re-running, reviewing, practicing the demo, mentor feedback).
