# Presentation (5 minutes) and Viva Answers

## Demo script

**1. The problem (30 sec).** "The Head of Sales needs to decide where to focus next quarter. I built a dashboard that shows revenue, orders, average order value and conversion by month, region and product."

**2. The data and cleaning (45 sec).** Open the Validation sheet. "The raw file had 7 problem rows: 2 duplicates, 2 missing regions, 1 negative quantity, 1 unknown product and 1 wrong revenue value. I fixed or removed them with a script and logged each decision. All reconciliation checks pass."

**3. The dashboard (90 sec).** Open the Dashboard. Point to the four cards, then the monthly chart. Switch the Region filter to South, then back to All. "Everything updates from the dropdowns."

**4. Findings (90 sec).** Open the Executive Summary. Walk through the 3 findings:
- Laptop Pro 15 is 37.5% of revenue (concentration risk).
- November traffic jumped 67% but orders only 38%, so conversion fell to 2.97%.
- South converts best but has the least traffic.

**5. Actions and limits (45 sec).** Three actions (test traffic to South, prepare checkout for November, bundle accessories and tighten discounts). Then say the data is simulated and regional differences are small, so an A/B test comes first.

## Viva / interview answers

**What business problem does it solve and how did you define success?**
It helps a Head of Sales choose where to focus next quarter. Success means the dashboard answers "which region and product, and why" in under two minutes, and every number can be traced and verified.

**Which decision had the biggest impact?**
Computing conversion as total orders divided by total visits, and keeping the raw data untouched while cleaning with a script. The first keeps KPIs correct; the second makes the work reproducible.

**How did you validate your work?**
I checked for duplicates, blanks, negative quantities, unknown products and revenue that did not match its components. I recalculated every KPI independently in Python and matched it to Excel (revenue $607,402.75), and the Validation sheet has live PASS/FAIL checks.

**What edge cases and limitations did you find?**
Missing regions, an unknown product ID, an impossible revenue value, and a negative quantity. Conversion cannot be split by category because traffic has no category. The data is simulated and regional conversion gaps are small.

**What if there were 10x the data?**
Excel would slow down at millions of rows. I would load data into a SQL database, aggregate there, and connect Power BI or Looker Studio to the summary tables.

**How would you explain it to a non-technical person?**
"It is a one-page scoreboard for sales. It shows how much we sold, where, what, and when, and where we are losing customers before they buy."

**Which part needed the most independent problem-solving?**
Deciding what to do with each bad row, for example keeping missing-region orders as "Unassigned" rather than deleting real revenue, and recalculating the wrong revenue value from its components.

## Practice tip

Be ready to change a filter and explain one number from scratch, for example "East revenue is the sum of revenue for East orders: $181,290".
